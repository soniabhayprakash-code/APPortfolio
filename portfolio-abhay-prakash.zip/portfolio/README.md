# Abhay Prakash — Portfolio Website

A full-stack developer portfolio built with HTML5, CSS3, JavaScript, Node.js, Express.js, and MongoDB.

## 🚀 Quick Start

### Frontend Only (Static)
Just open `public/index.html` in any browser. No installation needed.

### Full Stack (with Backend)

**Prerequisites:** Node.js 18+, MongoDB (local or Atlas)

```bash
# 1. Install dependencies
npm install

# 2. Configure environment
cp .env.example .env
# Edit .env with your MongoDB URI, email credentials, etc.

# 3. Start development server
npm run dev

# 4. Production
npm start
```

Open http://localhost:3000

---

## 📁 Project Structure

```
portfolio/
├── public/
│   ├── index.html        # Main portfolio page
│   ├── style.css         # All styles (glassmorphism, animations)
│   ├── script.js         # Frontend logic, animations, GitHub API
│   └── resume.pdf        # ← ADD YOUR RESUME HERE
├── models/
│   └── index.js          # Mongoose models (Contact, Visitor, Project, Blog)
├── routes/
│   └── api.js            # Express API routes
├── server.js             # Main Node.js server
├── .env.example          # Environment variables template
└── package.json
```

---

## ⚙️ Configuration

Copy `.env.example` to `.env` and fill in:

| Variable | Description |
|---|---|
| `MONGODB_URI` | MongoDB connection string |
| `PORT` | Server port (default: 3000) |
| `EMAIL_USER` | Gmail address for notifications |
| `EMAIL_PASS` | Gmail App Password (not your login password) |
| `EMAIL_TO` | Where to send contact form notifications |
| `ADMIN_PASSWORD` | Password for admin API access |

---

## 📡 API Endpoints

| Method | Endpoint | Description |
|---|---|---|
| `POST` | `/api/contact` | Submit contact form |
| `GET` | `/api/projects` | Get all projects |
| `GET` | `/api/blog` | Get blog posts |
| `GET` | `/api/blog/:slug` | Get single blog post |
| `GET` | `/api/resume` | Download resume |
| `POST` | `/api/track` | Visitor analytics |
| `GET` | `/api/admin/messages` | Admin: view messages |
| `GET` | `/api/admin/analytics` | Admin: view stats |
| `POST` | `/api/admin/projects` | Admin: add project |
| `POST` | `/api/admin/blog` | Admin: publish post |

**Admin endpoints** require header: `x-admin-token: YOUR_ADMIN_PASSWORD`

---

## 🎨 Design Features

- **Glassmorphism** cards with dynamic glow effects
- **Particle.js** interactive background on hero
- **Typed.js** animated text cycling
- **Vanilla Tilt** 3D hover on project cards
- **AOS** scroll animations
- **Dark/Light** theme toggle
- **Custom cursor** with trail effect
- **Magnetic buttons** that follow mouse
- **Animated skill bars** triggered on scroll
- **Counter animations** for statistics
- **GitHub API** live repository fetching

---

## 📧 Email Setup (Gmail)

1. Enable 2-Factor Authentication on Gmail
2. Go to Google Account → Security → App Passwords
3. Create an app password for "Mail"
4. Use that 16-character password as `EMAIL_PASS`

---

## 🌐 Deployment

### Vercel / Netlify (Frontend Only)
Deploy the `public/` folder.

### Railway / Render / Heroku (Full Stack)
```bash
# Set environment variables in dashboard
# Deploy whole project
```

### VPS (Ubuntu)
```bash
npm install -g pm2
pm2 start server.js --name "portfolio"
pm2 startup && pm2 save
```

---

## 📝 Customization

1. **Resume:** Replace `public/resume.pdf` with your resume
2. **Email:** Update contact email in `index.html` and `.env`
3. **GitHub:** Username is `soniabhayprakash-code` — update in `script.js` if needed
4. **Projects:** Add via Admin API or directly in `index.html`
5. **Profile Photo:** Replace the avatar placeholder in `index.html`

---

**Designed & Developed by Abhay Prakash** | CSE Student, BBDU Lucknow
